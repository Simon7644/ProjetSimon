<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class GuitareController extends Controller
{
    public function pageguitare(){
        return view('guitare');
    }
}

</body>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
<footer>
<div class="card text-center">
  <div class="card-header">
    Projet Simon
  </div>
  <div class="card-body">
    <h5 class="card-title">Projet Simon</h5>
    <p class="card-text">Réalisé avec Laravel</p>
  </div>
  <div class="card-footer text-muted">
  © Copyrights Lorem Ipsum
  </div>
</div>
</footer><?php /**PATH C:\Users\Simon\Desktop\ProjetSimon\resources\views/includes/footer.blade.php ENDPATH**/ ?>
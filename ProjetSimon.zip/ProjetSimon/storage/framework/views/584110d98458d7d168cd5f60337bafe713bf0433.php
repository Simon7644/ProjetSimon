<!DOCTYPE html>
<html lang="fr">
<head> 

<!-- style -->
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/style.css')); ?>">
 <!-- google fonts -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Comfortaa&family=Montserrat:wght@300&display=swap" rel="stylesheet">

<!-- bootstrap -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Projet Simon</title>
</head>

<header>
<ul class="nav justify-content-center">
  
  <li class="nav-item">
    <a class="nav-link" href="<?php echo e(url('/')); ?>">Accueil</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="<?php echo e(url('/contact')); ?>">Contact</a>
  </li>
  
</ul>
</header>
<body>
    
<?php /**PATH C:\Users\Simon\Desktop\ProjetSimon\resources\views/includes/header.blade.php ENDPATH**/ ?>
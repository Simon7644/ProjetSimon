<?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="card bg-dark text-white">
  <img src="banaccueil.jpg" class="card-img" alt="Bannière de l'accueil représentant un piano et une guitare">
  <div class="card-img-overlay">
    <h1 class="card-title">Bienvenue</h1>
    <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed non risus.<br>
     Suspendisse lectus tortor, dignissim sit amet, adipiscing nec, ultricies sed, dolor.<br>
    Cras elementum ultrices diam. Maecenas ligula massa, varius a, semper congue, euismod non, mi.<br>
     Proin porttitor, orci nec nonummy molestie, enim est eleifend mi, non fermentum diam nisl sit amet erat.<br>
      Duis semper. Duis arcu massa, scelerisque vitae, consequat in, pretium a, enim. Pellentesque congue.</p>
  </div>
</div>

<div id="articles">
<div class="card" style="width: 18rem;">
  <img src="piano.jpg" class="card-img-top" alt="Image de piano">
  <div class="card-body">
    <h2 class="card-title">Le piano et moi</h2>
    <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed non risus.</p>
    <a href="<?php echo e(url('piano')); ?>" class="btn btn-secondary">Lire l'article</a>
  </div>
</div>

<div class="card" style="width: 18rem;">
  <img src="guitare.jpg" class="card-img-top" alt="Image de guitare">
  <div class="card-body">
    <h2 class="card-title">La guitare et moi</h2>
    <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed non risus.</p>
    <a href="<?php echo e(url('guitare')); ?>" class="btn btn-secondary">Lire l'article</a>
  </div>
</div>

</div>

<?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Simon\Desktop\ProjetSimon\resources\views/accueil.blade.php ENDPATH**/ ?>
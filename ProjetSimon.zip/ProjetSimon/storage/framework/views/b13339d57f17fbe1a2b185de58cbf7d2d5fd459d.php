<?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<ul class="list-group list-group-flush">
  <li class="list-group-item">Tel: 01 02 03 04 05</li>
  <li class="list-group-item">Mail: mail@arinfo.com</li>
</ul>
<?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Simon\Desktop\ProjetSimon\resources\views//contact.blade.php ENDPATH**/ ?>
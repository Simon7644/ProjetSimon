@include('includes.header')
<ul class="list-group list-group-flush">
  <li class="list-group-item">Tel: 01 02 03 04 05</li>
  <li class="list-group-item">Mail: mail@arinfo.com</li>
</ul>
@include('includes.footer')
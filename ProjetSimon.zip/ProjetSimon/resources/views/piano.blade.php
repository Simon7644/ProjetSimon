@include('includes.header')

<div class="single">

<div class="card mb-3" style="max-width: 540px;">
  <div class="row g-0">
    <div class="col-md-4">
      <img src="piano.jpg" class="img-fluid rounded-start" alt="...">
    </div>
    <div class="col-md-8">
      <div class="card-body">
        <h2 class="card-title">Le piano et moi</h2>
        <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed non risus.<br>
     Suspendisse lectus tortor, dignissim sit amet, adipiscing nec, ultricies sed, dolor.<br>
    Cras elementum ultrices diam. Maecenas ligula massa, varius a, semper congue, euismod non, mi.<br>
     Proin porttitor, orci nec nonummy molestie, enim est eleifend mi, non fermentum diam nisl sit amet erat.<br>
      Duis semper. Duis arcu massa, scelerisque vitae, consequat in, pretium a, enim. Pellentesque congue.</p>
      </div>
    </div>
  </div>
</div>

</div>

@include('includes.footer')